Tutoriel d'utilisation :
Extraire et conserver les fichier dans le dossier, ne pas les renommés.
Lancer le script Webscraping.sh ou Webscraping.ps1 (powershell) selon votre environnement, nous vous recommandons le script bash qui est bien plus abouti.
Suivez les instructions.
Les logs se situent dans le dossier "logs_webscrap"
Les fichier avec une extension ".p" sont des modules contenant les commandes pour tracés dans gnuplot
Les fichiers en .dat servent de base de données pour le tracé avec gnuplot.
Un fichier avec des données arbitraire est disponible afin de verifier le bon fonctionnement général.