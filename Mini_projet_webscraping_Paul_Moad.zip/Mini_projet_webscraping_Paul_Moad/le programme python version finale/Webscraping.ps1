####### Affichage ########
function affichage{
    echo "Webscrappeur automatise compose de deux scripts python et un script bash "
    echo " Realise par Paul Berra et Moad Razzaki - Tous droits reserves "
    echo ""
}
affichage
$choix = Read-Host " > Consulter les parkings velo(1) ou voiture(2) [3 pour un bonus] (1/2) " 

###### choix parking velo/voiture #######
$choix1 = 1
$choix2 = 2
$choix3 = 3

if ( "${choix}" -eq "${choix1}" )
{
	python3 "Webscraping_velo.py"
}
elseif ( "${choix}" -eq "${choix2}" )
{
	python3 "webscraping_voiture.py"
} 

elseif( "${choix}" -eq "{$choix3}" )
{
    [console]::beep(440,500)
    [console]::beep(440,500)
    [console]::beep(440,500)
    [console]::beep(349,350)
    [console]::beep(523,150)
    [console]::beep(440,500)
    [console]::beep(349,350)
    [console]::beep(523,150)
    [console]::beep(440,1000)
    [console]::beep(659,500)
    [console]::beep(659,500)
    [console]::beep(659,500)
    [console]::beep(698,350)
    [console]::beep(523,150)
    [console]::beep(415,500)
    [console]::beep(349,350)
    [console]::beep(523,150)
    [console]::beep(440,1000)	
}
else
{
	echo " Wrong input... Try again !"
}

sleep 5


