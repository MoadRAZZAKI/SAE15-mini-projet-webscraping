
##################################### Importations ####################################
from tkinter import W
from xml.dom import minidom
import urllib
from xml.sax.xmlreader import XMLReader
import requests
from datetime import datetime
import time
from math import sqrt
import os
##################################### Variables #####################################
total=[]
free=[]
names=[]
occupesv=[]
fic1='TAM_MMM_VELOMAG.xml'
URL = "https://data.montpellier3m.fr/sites/default/files/ressources/TAM_MMM_VELOMAG.xml"
i=0
y=0
c=0
x = int(input("Entrez le temps entre deux échantillonages, en seconde : "))
############################ convertir le lien en fichier xml #################################
def url_to_fic(URL):
    urllib.request.urlretrieve(URL, "TAM_MMM_VELOMAG.xml")  
##################### parse le fichier xml en s'appuyant sur les tags ########################
def parsing_velo(fic):
    xmldoc = minidom.parse(fic)
    itemlist = xmldoc.getElementsByTagName('si')
    for s in itemlist:
        a=s.attributes['na'].value
        names.append(a)
    for s in itemlist:
        b=s.attributes['fr'].value
        free.append(int(b))
    for s in itemlist:
        c=s.attributes['to'].value
        total.append(int(c))
    return total, free, names
########################### APPEL DES FONCTIONS ##################################
def url_parsing(URL, fic1):
    url_to_fic(URL)
    parsing_velo(fic1)
########################## CALCUL DES PLACES OCCUPEES ###################################
def places_occupesv(freev, total, i, occupesv): #soustrait les places libres aux places total pour avoir les places occupés
    for i in range(len(free)) :
        z = int(total[i])
        zz = int(free[i])
        y = z-zz
        occupesv.append(y)
############################### FONCTION QUI AFFICHE LES INFORMATIONS ######################
def affichage_donnee(names,total,free,occupesv):
    print('***********************************')
    print('les noms de parkings sont : ', names)
    print('***********************************')
    print('les places total des parkings des vélos sont : ' , total)
    print('***********************************')
    print('les places libres des parkings des vélos sont : ', free)
    print('***********************************')
    print('les places occupées des parkings des vélos sont : ', occupesv)

def printt(occupesv, taux):
    print('***********************************')
    print('la somme de tout les parkings occupées par les vélos est : ',somme(occupesv))
    print('***********************************')
    print("le taux d'occupation des parking vélo est : " , round(taux(),0),"%")
    print('***********************************')
################################# calcule la somme #####################################
def somme(occupesv): # calcul de la somme des places occupés
    s=0
    for r in occupesv:
        s=s+r
    return s
################################ calcule le taux #####################################
def taux():
    x=(somme(occupesv)*100)/somme(total)
    return x
############################ calcule de l'écart type #################################
def sigma(occupesv):
    k = len(occupesv)
    n = 0
    x = 0
    m = 0
    for b in occupesv:
        x = x+b
    m = x/k
    for z in occupesv:
        n=n+(z-m)**2
    w=sqrt((1/k)*n)
    return w
############################## ecriture du fichier de données ################################

def fichier_donnees(x,w): 
    datee = str(datetime.today())
    heure = datee[11:13]
    f5=open('logs_webscrap/datav.dat', 'a', encoding='utf8')
    f5.write(str(heure))
    f5.write(str(" "))
    f5.write(str(round(x,2)))
    f5.write(str(" "))
    f5.write(str(round(w,2)))
    f5.write('\n')
    f5.close()
def calcul_affichage(names,total,free,occupesv):
    somme(occupesv)
    sigma(occupesv)
    affichage_donnee(names,total,free,occupesv)
    fichier_donnees(taux(),sigma(occupesv))


##################################### Init ###########################################

def init(URL, fic1, free, total, i , occupesv, taux, names,sigma):    
    try:
        url_parsing(URL, fic1)    
        places_occupesv(free,total,i,occupesv)    
        calcul_affichage(names,total,free,occupesv)
        printt(occupesv, taux)

    except ValueError:
        init(URL, fic1, free, total, i , occupesv, taux, names) # si bug ou site vide, on retry

def ecriture(fichier_name, names, total, free): # ouvre un fichier portant le nom donné par renommage_fichier() et y entre les valeurs parser, pas utile pour les calculs mais sert de logs
    datee = str(datetime.today())
    heure = datee[10:16]
    for v in range(len(names)) : 
        f2 = open('logs_webscrap/' + fichier_name, 'a', encoding='utf8')
        f2.write("heure : " + heure)
        f2.write('\n')
        f2.write('Nom du parking : ')
        m=names[v]
        f2.write(str(m))
        f2.write('\n')
        f2.write('Nombre total de places : ')
        y=total[v]
        f2.write(str(y))
        f2.write('\n')
        f2.write('Nombre de places libres : ')
        u=free[v]
        f2.write(str(u))
        f2.write('\n')
        f2.write('************************************')
        f2.write('\n')
        f2.close()

################

def renommage_fichier(): # cree un fichier de log journalisé en fonction de la date et l'heure
    fichier_name = "free_place_parking_velo"
    name_date = "_" + str(datetime.today())
    name_date = name_date[0:14]
    fichier_name += name_date +"h"
    fichier_name+= ".csv"
    return fichier_name

#################### creation dossier log ####################

def creation_dossier_log():#le nom parle de lui meme
    ###dossier racine des logs
    if os.path.isdir("logs_webscrap") == True :#si dossier existant je passe, sinon je le cree et je me déplace dedans
        pass
    else:
        os.mkdir("logs_webscrap")
        if os.path.isdir("logs_webscrap"):
            pass
        else:
            os.chdir("logs_webscrap")
            
################################ boucle infini ###################################

while c != 1:
    creation_dossier_log()
    init(URL, fic1, free, total, i , occupesv, taux, names,sigma)
    renommage_fichier()
    fichier_name = renommage_fichier()
    ecriture(fichier_name, names, total, free)
    time.sleep(x)
    ##################### remise a zero des variables ###############################
    total=[]
    free=[]
    names=[]
    occupesv=[]
    fichier_name = renommage_fichier()
    i=0
    y=0
    c=0