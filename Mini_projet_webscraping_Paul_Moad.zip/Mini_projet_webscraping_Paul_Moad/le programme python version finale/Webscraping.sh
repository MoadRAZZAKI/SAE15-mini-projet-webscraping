
#!/bin/env

####### couleurs ###########

red='\033[0;31m'
nc='\033[0m'

start(){
echo ' !!! SCRIPT NEED ROOT !!! '
sudo apt install gnuplot
clear
}

###### Affichage ###########
affichage() {
clear
echo -e " ${red} Webscrappeur automatisé composé de deux scripts python et un script bash "
echo -e " Réalisé par Paul Berra et Moad Razzaki - Tous droits réservés "
echo ''
echo -e " ${nc}"
read -p " > Consulter les parkings velo(1), voiture(2) ou afficher une courbe a partir d'un fichier pré-éxistant(3) ? (1/2/3) : " choix
echo ''
}
########## gnu scripting voiture ######
gnu_trace_voiture(){
gnuplot <<EOF
load 'script_voiture.p'
replot
EOF
echo "Courbe générée avec succès "
}
########## gnu scripting velo #########
gnu_trace_velo(){
gnuplot <<EOF
load 'script_vélo.p'
replot
EOF
echo "Courbe générée avec succès "
}
######### gnu scripting custom #######
gnu_trace_custom(){
clear
read -p "Entrez le nom du fichier de données a tracer : " fic
echo ''
read -p "Entrez le titre du graphique : " title
echo ''
read -p "Entrez le nom de l'axe de la courbe : " abs
echo ''
read -p "Entrez le nom du fichier 'png' de sortie : " ficname
gnuplot <<EOF
set title '${title}' font "Arial,11"
set key right box
set samples 20
set xtic rotate by -45
set style data points
plot '${fic}' using 1:2 title '${abs}' with lines linecolor rgb "#4BFF00", '${fic}' using 1:3 title 'écart type' with points
set term png
set output '${ficname}.png'
replot
EOF
echo "Courbe générée avec succès "
clear
}


###### choix parking velo/voiture #######
choix() {
choix1=1
choix2=2
choix3=3
if [[ "$choix" = "$choix1" ]]; then
	python3 "Webscraping_velo.py"
elif [[ "$choix" = "$choix2" ]]; then
        python3 "webscraping_voitures.py"
elif [[ "$choix" = "$choix3" ]]; then
	read -p "Afficher courbe parking voiture(1), velo(2) ou custom(3) ? (1/2/3): " courbe
	courbevoit=1
	courbevel=2
	courbecustom=3
	if [[ "${courbe}" = "${courbevoit}" ]]; then
		gnu_trace_voiture
	elif [[ "${courbe}" = "${courbevel}" ]]; then
		gnu_trace_velo
	elif [[ "${courbe}" = "${courbecustom}" ]]; then
		gnu_trace_custom
	else:
		 echo -e " ${red} Wrong entry... Try again ! : "
	fi
else:
        echo -e " ${red} Wrong entry... Try again ! : "
fi
}
######### Restart #############
restart(){
clear
echo ''
echo ''
while true; do
	read -p " Relancer le script ? (y/n) : " input
	case $input in
		[Yy]*) init; break;;
		[Nn]*) exit 0;;
		*) "wrong input...";;
	esac
done
}

############ Init ##############

init(){
start
affichage
choix
restart
}

########### Start ##########
init
