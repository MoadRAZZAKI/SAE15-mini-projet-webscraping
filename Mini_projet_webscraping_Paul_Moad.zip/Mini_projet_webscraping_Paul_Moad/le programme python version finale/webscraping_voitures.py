############################################################################################################################################################################################################################################################################################################################################################
# importations
from math import sqrt
import numpy as np
import time
import requests
from lxml import etree
from bs4 import BeautifulSoup
from datetime import datetime
import os
import matplotlib.pyplot as plt1

import numpy as np
from os import system, remove
#import gnuplot 
############################################################################################################################################################################################################################################################################################################################################################

#infos utiles
# vide pour l'instant

############################################################################################################################################################################################################################################################################################################################################################
    #definition des variables réccurentes
path = "https://data.montpellier3m.fr/sites/default/files/ressources/"
tag = ['FR_MTP_ANTI','FR_MTP_COME','FR_MTP_CORU','FR_MTP_EURO','FR_MTP_FOCH','FR_MTP_GAMB','FR_MTP_GARE','FR_MTP_TRIA','FR_MTP_ARCT','FR_MTP_PITO','FR_MTP_CIRC','FR_MTP_SABI','FR_MTP_GARC','FR_MTP_SABL','FR_MTP_MOSS','FR_STJ_SJLC','FR_MTP_MEDC','FR_MTP_OCCI','FR_CAS_VICA','FR_MTP_GA109','FR_MTP_GA250','FR_CAS_CDGA','FR_MTP_ARCE','FR_MTP_POLY']
ext = ".xml"
i = 0 #i est la variable qui se deplace dans la liste des tag, il sert de métronome au programme
c = 0 # c est un "compteur" inutile, il sert juste a faire tourner la boucle while à l'infini
x = int(input("Entrez la durée entre deux échantillonages (en secondes) : ")) # input  du sleep
free = [] #places libres
tot = [] #places total
names = ('Antigone', "Comedie", "Corum", "Europa", "Foch", "Gambetta", "Gare saint Roch", "Triangle", "Arc de Triomphe", "Pitot", "Circe", "Sabines", "Garcia Lorca", "Sablassou", "Mosson", "Saint Jean Le Sec", "Euromédecine", "Occitanie", "Vicarello", "Gaumont EST", "Charles de Gaulle", "Arceaux", "Polygone")
names = str(names)
occupes = []
############################################################################################################################################################################################################################################################################################################################################################

###############################################################

def taux(occupes, moy): # calcul du taux d'occupation
    somme_tot = somme(tot)
    taux = (moy * 100) // somme_tot
    print('\n', "**********************")
    print("Taux d'occupation voiture : ", taux, "%")
    print("**********************")

##########################################################

##########################################################
# fonctions impactant des manipulation du systeme de fichier, ecriture, renommage..

def ecriture(fichier_name, nom, total, libre, statu): # ouvre un fichier portant le nom donné par renommage_fichier() et y entre les valeurs parser, pas utile pour les calculs mais sert de logs
    datee = str(datetime.today())
    heure = datee[10:16]
    f2 = open("logs_webscrap/" + fichier_name, 'a', encoding='utf8')
    f2.write("heure : " + heure)
    f2.write('\n')
    f2.write('Nom du parking : ')
    f2.write(str(nom))
    f2.write('\n')
    f2.write('Status : ')
    f2.write(str(statu))
    f2.write('\n')
    f2.write('Nombre total de places : ')
    f2.write(str(total))
    f2.write('\n')
    f2.write('Nombre de places libres : ')
    f2.write(str(libre))
    f2.write('\n')
    f2.write('************************************')
    f2.write('\n')
    f2.close()

################

def renommage_fichier(): # cree un fichier de log journalisé en fonction de la date et l'heure
    fichier_name = "free_place_parking"
    name_date = "_" + str(datetime.today())
    name_date = name_date[0:14]
    fichier_name += name_date +"h"
    fichier_name+= ".csv"
    return fichier_name

################

def creation_dossier_log(fichier_name):#le nom parle de lui meme
    ###dossier racine des logs
    if os.path.isdir("logs_webscrap") == True :#si dossier existant je passe, sinon je le cree et je me déplace dedans
        pass
    else:
        os.mkdir("logs_webscrap")
        if os.path.isdir("logs_webscrap"):
            pass
        else:
            os.chdir("logs_webscrap")

##########################################################
            
def fichier_donnees(tot,free,moy,sig,heure,names):
    datee = str(datetime.today())
    heure = datee[11:13]   
    f5=open("data.dat", 'a', encoding='utf8')
    f5.write(str(heure))
    f5.write(str(" "))
    f5.write(str(moy))
    f5.write(str(" "))
    f5.write(str(sig))
    f5.write('\n')
    f5.close()
    
##########################################################
def parsing(texte, i):
#parse le contenu retourner par requete
    try:#recupere le texte dans la balise nom 
        soup = BeautifulSoup(texte,"html.parser")
        name = soup.find('name')
        nom = name.text
    #recupere le texte dans la balise free
        free = soup.find('free')
        libre = free.text    
    #recupere le texte dans la balise status 
        status = soup.find('status')
        statu = status.text
    #recupere le texte dans la balise total
        total = soup.find('total')
        total = total.text
        print("............................................... ")
        print("Requete vers le parking de " + nom + " effectuee ")
    except AttributeError:
        try:
            nom, libre, statu, total = ""
        except ValueError :    
            nom, libre, statu, total = "Pas de données éxploitables sur le parking   [code 3]", "Pas de données éxploitables sur le parking    [code 3]", "Pas de données éxploitables sur le parking    [code 3]", "Pas de données éxploitables sur le parking    [code 3]"
            exit
    return nom, libre, statu, total
##########################################################

##########################################################
def requete(url, tag, i): #effectue requete et retourne le contenu
    response = requests.get(url)#requete pour avoir le contenu xml de la page

    if response.ok == True: #verifie que c'est bien un code 200, sinon refait la meme requete
        texte = str(response.text)
        #### petit compteur de requete sur le nombre total           
        j = i + 1 #petit detail pour que ca commence a 1 c'est plus parlant
        print(j,"/",len(tag))
        ###    
    else:
        print("Difficulté a joindre les données du parking " + tag[i], "   [code 1.1]")
        texte = "Empty data"
        pass
    return texte
        
def construction_urls(path, tag, ext, i): # construit l'url sur le quel i pointe actuellement
    url = path + tag[i] + ext
    return url

def constructeur_url(path, tag, ext, i): # organise la construction, extraction, creation d'un fichier de log et y rentre les données utiles
    url = construction_urls(path, tag, ext, i)
    texte = requete(url, tag, i)
    nom, libre, statu, total = parsing(texte, i)
    fichier_name = renommage_fichier()
    creation_dossier_log(fichier_name)
    ecriture(fichier_name, nom, total, libre, statu)
    i +=1
    return nom, libre, statu, total, i
   
def action_sur_les_fichiers(path, tag, ext, i):# recuperation et ecriture des données extraites
    nom, libre, statu, total, i = constructeur_url(path, tag, ext, i)

    return nom, libre, statu, total, i
   
def init(path, tag, ext, i, free, tot, occupes): #Constructeur global
    while i < len(tag):

        nom, libre, statu, total, i = action_sur_les_fichiers(path, tag, ext, i)

        try :
            total = int(total)
            libre = int(libre)
        ###
            free.append(libre)# complete les listes déclarés a vide a la racine pour une utilisation dans les fonctions mathématique simplifé
            tot.append(total)
        except ValueError:
            total = total
            libre = libre
            free.append("Pas de valeur exploitable", "   [code 2]")
            libre.append("Pas de valeur exploitable", "   [code 2.1]")
            
        if i == len(tag): #si liste des tags parcourus
            places_occupes(free, tot, i, occupes)
            sig, moy = maths(names, occupes)
            s = somme(occupes)
            x = taux(s)
            fichier_donnees(tot,free,x,sig,heure,names)
            affichage_moy(occupes, sig, moy,x)
        


def affichage_moy(occupes, sig, moy,x):
    print("taux des places occupées dans les parkings de montpellier est ", round(x,2))
    print("")
    print ("Ecart type de la mesure (a un instant t) : ", sig)

###########################

def fichier_donnees(tot,free,x,sig,heure,names):
    datee = str(datetime.today())
    heure = datee[11:13]   
    f5=open("data.dat", 'a', encoding='utf8')
    f5.write(str(heure))
    f5.write(str(" "))
    f5.write(str(round(x,2)))
    f5.write(str(" "))
    f5.write(str(sig))
    f5.write('\n')
    f5.close()


#######################
## tool pour avoir l'heure pour le renommage des logs
def heure():
    date = str(datetime.today())
    heure = date[10:16]
    return heure

############################################################################################################
# fonctions mathématique

def places_occupes(free, tot, i, occupes):
    for i in range(24) :
        z = int(tot[i])
        zz = int(free[i])
        z = z-zz
        occupes.append(z)

def somme(occupes): # calcul de la somme des places occupés
    s=0
    for r in occupes:
        s=s+r
    return s

def taux(s):
    s=(somme(occupes)*100)/somme(tot)
    return s

def moyenne(occupes):
    x=0
    k=0
    m=0
    for r in occupes:
        x=x+r
        k=k+1
    m=x/k
    return m

def sigma(occupes):
    k = len(occupes)
    n = 0
    x = 0
    m = 0
    for b in occupes:
        x = x+b
    m = x/k
    for z in occupes:
        n=n+(z-m)**2
    w=sqrt((1/k)*n)
    return w

def maths(names, occupes):# fonction organisant le déploiement des differentes fonctions mathématiques
    moy = moyenne(occupes)
    sig = round(sigma(occupes), 2)
    return sig, moy

############################################################################################################################################################################################################################################################################################################################################################
 
 #lancement dans une boucle infini

while c != 1:
    try:
        print("Mise a jour des données... ")
        j = init(path, tag, ext, i, free, tot, occupes)
        time.sleep(x) #fait une pause de x  entre 2 recuperation de données (input du debut)
    except TypeError: # si le programme remonte une erreur critique, i est incrémenté et le script passe au parking suivant
       i+=1